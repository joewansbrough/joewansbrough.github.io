---
layout: default
title: About
permalink: /about/
---

# About Joltin' Joe's Hot Sauce

Add your story here! Tell visitors about:

- How you started making hot sauce
- What makes your sauces special
- Your commitment to quality and flavor
- Your background and passion for hot sauce

## Contact

**Email:** joe@joltinjoeshotsauce.com

Replace this placeholder content with your actual story and information.
